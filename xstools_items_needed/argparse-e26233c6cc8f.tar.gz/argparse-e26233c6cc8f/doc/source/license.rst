arparse Copyright and License
=============================

.. _license:

.. literalinclude:: ../../LICENSE.txt

This is the Python License (from file doc/Python-License.txt):

.. literalinclude:: Python-License.txt

